// Profile and social features API functions for GYMTOPIA 2.0
// PRODUCTION VERSION - DATABASE ONLY (No mock data)

import { createClient } from '@supabase/supabase-js'
import type {
  UserProfile,
  UserProfileStats,
  GymPost,
  CreateGymPostInput,
  UpdateGymPostInput,
  PostComment,
  CreatePostCommentInput,
  Follow,
  GymFriend,
  GymFriendRequestInput,
  FavoriteGym,
  WeeklyStats,
  ProfileDashboard,
  UpdateProfileInput
} from '../types/profile'
import type { Achievement, PersonalRecord } from '../types/workout'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const supabase = createClient(supabaseUrl, supabaseAnonKey)

// ========================================
// USER PROFILE FUNCTIONS
// ========================================

export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single()

    if (error) {
      console.error('Error fetching user profile:', error)
      return null
    }
    
    return data as UserProfile
  } catch (error) {
    console.error('Error fetching user profile:', error)
    return null
  }
}

export async function getUserProfileStats(userId: string): Promise<UserProfileStats | null> {
  try {
    const { data, error } = await supabase
      .from('user_profile_stats')
      .select('*')
      .eq('user_id', userId)
      .single()

    if (error) {
      console.error('Error fetching user profile stats:', error)
      return null
    }
    
    return data as UserProfileStats
  } catch (error) {
    console.error('Error fetching user profile stats:', error)
    return null
  }
}

export async function updateUserProfile(
  userId: string, 
  updates: UpdateProfileInput
): Promise<UserProfile | null> {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', userId)
      .select()
      .single()

    if (error) {
      console.error('Error updating user profile:', error)
      return null
    }
    
    return data as UserProfile
  } catch (error) {
    console.error('Error updating user profile:', error)
    return null
  }
}

// ========================================
// GYM POSTS FUNCTIONS
// ========================================

export async function getUserPosts(
  userId: string,
  page = 1,
  limit = 10
): Promise<GymPost[]> {
  try {
    const offset = (page - 1) * limit

    const { data, error } = await supabase
      .from('gym_posts')
      .select(`
        *,
        user:profiles(id, display_name, username, avatar_url, is_verified),
        workout_session:workout_sessions(
          id, started_at, ended_at,
          gym:gyms(id, name, area)
        )
      `)
      .eq('user_id', userId)
      .eq('is_public', true)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)

    if (error) {
      console.error('Error fetching user posts:', error)
      return []
    }
    
    return data as GymPost[]
  } catch (error) {
    console.error('Error fetching user posts:', error)
    return []
  }
}

export async function createGymPost(
  userId: string,
  postData: CreateGymPostInput
): Promise<GymPost | null> {
  try {
    const { data, error } = await supabase
      .from('gym_posts')
      .insert({
        user_id: userId,
        ...postData
      })
      .select(`
        *,
        user:profiles(id, display_name, username, avatar_url, is_verified)
      `)
      .single()

    if (error) {
      console.error('Error creating gym post:', error)
      return null
    }
    
    return data as GymPost
  } catch (error) {
    console.error('Error creating gym post:', error)
    return null
  }
}

export async function updateGymPost(
  postId: string,
  updates: UpdateGymPostInput
): Promise<GymPost | null> {
  try {
    const { data, error } = await supabase
      .from('gym_posts')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', postId)
      .select()
      .single()

    if (error) {
      console.error('Error updating gym post:', error)
      return null
    }
    
    return data as GymPost
  } catch (error) {
    console.error('Error updating gym post:', error)
    return null
  }
}

export async function deleteGymPost(postId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('gym_posts')
      .delete()
      .eq('id', postId)

    if (error) {
      console.error('Error deleting gym post:', error)
      return false
    }
    
    return true
  } catch (error) {
    console.error('Error deleting gym post:', error)
    return false
  }
}

export async function likePost(userId: string, postId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('post_likes')
      .insert({
        user_id: userId,
        post_id: postId
      })

    if (error) {
      console.error('Error liking post:', error)
      return false
    }
    
    return true
  } catch (error) {
    console.error('Error liking post:', error)
    return false
  }
}

export async function unlikePost(userId: string, postId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('post_likes')
      .delete()
      .eq('user_id', userId)
      .eq('post_id', postId)

    if (error) {
      console.error('Error unliking post:', error)
      return false
    }
    
    return true
  } catch (error) {
    console.error('Error unliking post:', error)
    return false
  }
}

// ========================================
// COMMENTS FUNCTIONS
// ========================================

export async function getPostComments(
  postId: string,
  page = 1,
  limit = 20
): Promise<PostComment[]> {
  try {
    const offset = (page - 1) * limit

    const { data, error } = await supabase
      .from('post_comments')
      .select(`
        *,
        user:profiles(id, display_name, username, avatar_url, is_verified),
        replies:post_comments(
          *,
          user:profiles(id, display_name, username, avatar_url, is_verified)
        )
      `)
      .eq('post_id', postId)
      .is('parent_comment_id', null)
      .order('created_at', { ascending: true })
      .range(offset, offset + limit - 1)

    if (error) {
      console.error('Error fetching post comments:', error)
      return []
    }
    
    return data as PostComment[]
  } catch (error) {
    console.error('Error fetching post comments:', error)
    return []
  }
}

export async function createComment(
  userId: string,
  commentData: CreatePostCommentInput
): Promise<PostComment | null> {
  try {
    const { data, error } = await supabase
      .from('post_comments')
      .insert({
        user_id: userId,
        ...commentData
      })
      .select(`
        *,
        user:profiles(id, display_name, username, avatar_url, is_verified)
      `)
      .single()

    if (error) {
      console.error('Error creating comment:', error)
      return null
    }
    
    return data as PostComment
  } catch (error) {
    console.error('Error creating comment:', error)
    return null
  }
}

// ========================================
// SOCIAL FUNCTIONS
// ========================================

export async function followUser(followerId: string, followingId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('follows')
      .insert({
        follower_id: followerId,
        following_id: followingId
      })

    if (error) {
      console.error('Error following user:', error)
      return false
    }
    
    return true
  } catch (error) {
    console.error('Error following user:', error)
    return false
  }
}

export async function unfollowUser(followerId: string, followingId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('follows')
      .delete()
      .eq('follower_id', followerId)
      .eq('following_id', followingId)

    if (error) {
      console.error('Error unfollowing user:', error)
      return false
    }
    
    return true
  } catch (error) {
    console.error('Error unfollowing user:', error)
    return false
  }
}

export async function getUserFollowers(
  userId: string,
  page = 1,
  limit = 20
): Promise<Follow[]> {
  try {
    const offset = (page - 1) * limit

    const { data, error } = await supabase
      .from('follows')
      .select(`
        *,
        follower:profiles!follower_id(id, display_name, username, avatar_url, is_verified)
      `)
      .eq('following_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)

    if (error) {
      console.error('Error fetching followers:', error)
      return []
    }
    
    return data as Follow[]
  } catch (error) {
    console.error('Error fetching followers:', error)
    return []
  }
}

export async function getUserFollowing(
  userId: string,
  page = 1,
  limit = 20
): Promise<Follow[]> {
  try {
    const offset = (page - 1) * limit

    const { data, error } = await supabase
      .from('follows')
      .select(`
        *,
        following:profiles!following_id(id, display_name, username, avatar_url, is_verified)
      `)
      .eq('follower_id', userId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)

    if (error) {
      console.error('Error fetching following:', error)
      return []
    }
    
    return data as Follow[]
  } catch (error) {
    console.error('Error fetching following:', error)
    return []
  }
}

// ========================================
// GYM FRIENDS FUNCTIONS
// ========================================

export async function sendGymFriendRequest(
  requestData: GymFriendRequestInput
): Promise<GymFriend | null> {
  try {
    const { data, error } = await supabase
      .from('gym_friends')
      .insert(requestData)
      .select(`
        *,
        user1:profiles!user1_id(id, display_name, username, avatar_url),
        user2:profiles!user2_id(id, display_name, username, avatar_url),
        gym:gyms(id, name, area)
      `)
      .single()

    if (error) {
      console.error('Error sending gym friend request:', error)
      return null
    }
    
    return data as GymFriend
  } catch (error) {
    console.error('Error sending gym friend request:', error)
    return null
  }
}

export async function acceptGymFriendRequest(
  requestId: string
): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('gym_friends')
      .update({
        friendship_status: 'accepted',
        accepted_at: new Date().toISOString()
      })
      .eq('id', requestId)

    if (error) {
      console.error('Error accepting gym friend request:', error)
      return false
    }
    
    return true
  } catch (error) {
    console.error('Error accepting gym friend request:', error)
    return false
  }
}

export async function getUserGymFriends(userId: string): Promise<GymFriend[]> {
  try {
    const { data, error } = await supabase
      .from('gym_friends')
      .select(`
        *,
        user1:profiles!user1_id(id, display_name, username, avatar_url),
        user2:profiles!user2_id(id, display_name, username, avatar_url),
        gym:gyms(id, name, area)
      `)
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .eq('friendship_status', 'accepted')

    if (error) {
      console.error('Error fetching gym friends:', error)
      return []
    }
    
    return data as GymFriend[]
  } catch (error) {
    console.error('Error fetching gym friends:', error)
    return []
  }
}

// ========================================
// FAVORITE GYMS FUNCTIONS
// ========================================

export async function getFavoriteGyms(userId: string): Promise<FavoriteGym[]> {
  try {
    const { data, error } = await supabase
      .from('favorite_gyms')
      .select(`
        *,
        gym:gyms(*)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Error fetching favorite gyms:', error)
      return []
    }
    
    return data as FavoriteGym[]
  } catch (error) {
    console.error('Error fetching favorite gyms:', error)
    return []
  }
}

export async function addFavoriteGym(userId: string, gymId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('favorite_gyms')
      .insert({
        user_id: userId,
        gym_id: gymId
      })

    if (error) {
      console.error('Error adding favorite gym:', error)
      return false
    }
    
    return true
  } catch (error) {
    console.error('Error adding favorite gym:', error)
    return false
  }
}

export async function removeFavoriteGym(userId: string, gymId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('favorite_gyms')
      .delete()
      .eq('user_id', userId)
      .eq('gym_id', gymId)

    if (error) {
      console.error('Error removing favorite gym:', error)
      return false
    }
    
    return true
  } catch (error) {
    console.error('Error removing favorite gym:', error)
    return false
  }
}

// ========================================
// STATISTICS FUNCTIONS
// ========================================

export async function getWeeklyStats(userId: string): Promise<WeeklyStats | null> {
  try {
    const { data, error } = await supabase
      .from('workout_sessions')
      .select('*')
      .eq('user_id', userId)
      .gte('started_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())
      .order('started_at', { ascending: false })

    if (error) {
      console.error('Error fetching weekly stats:', error)
      return null
    }

    // Calculate weekly statistics
    const totalSessions = data.length
    const totalWeightLifted = data.reduce((sum, session) => sum + (session.total_weight_lifted || 0), 0)
    const totalDuration = data.reduce((sum, session) => {
      if (session.started_at && session.ended_at) {
        return sum + (new Date(session.ended_at).getTime() - new Date(session.started_at).getTime())
      }
      return sum
    }, 0)

    return {
      id: `weekly-stats-${userId}`,
      user_id: userId,
      week_start_date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      week_end_date: new Date().toISOString(),
      total_sessions: totalSessions,
      total_weight_lifted: totalWeightLifted,
      total_duration_minutes: Math.floor(totalDuration / (1000 * 60)),
      average_session_duration: totalSessions > 0 ? Math.floor(totalDuration / (totalSessions * 1000 * 60)) : 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    } as WeeklyStats
  } catch (error) {
    console.error('Error fetching weekly stats:', error)
    return null
  }
}

export async function getUserAchievements(userId: string): Promise<Achievement[]> {
  try {
    const { data, error } = await supabase
      .from('achievements')
      .select('*')
      .eq('user_id', userId)
      .order('earned_at', { ascending: false })

    if (error) {
      console.error('Error fetching achievements:', error)
      return []
    }
    
    return data as Achievement[]
  } catch (error) {
    console.error('Error fetching achievements:', error)
    return []
  }
}

export async function getUserPersonalRecords(userId: string): Promise<PersonalRecord[]> {
  try {
    const { data, error } = await supabase
      .from('personal_records')
      .select('*')
      .eq('user_id', userId)
      .order('achieved_at', { ascending: false })

    if (error) {
      console.error('Error fetching personal records:', error)
      return []
    }
    
    return data as PersonalRecord[]
  } catch (error) {
    console.error('Error fetching personal records:', error)
    return []
  }
}

// ========================================
// DASHBOARD FUNCTIONS
// ========================================

export async function getProfileDashboard(userId: string): Promise<ProfileDashboard | null> {
  try {
    const [profileStats, weeklyStats, recentPosts, achievements, personalRecords] = await Promise.all([
      getUserProfileStats(userId),
      getWeeklyStats(userId),
      getUserPosts(userId, 1, 5),
      getUserAchievements(userId),
      getUserPersonalRecords(userId)
    ])

    if (!profileStats) {
      return null
    }

    return {
      profile_stats: profileStats,
      weekly_stats: weeklyStats,
      recent_posts: recentPosts,
      achievements: achievements.slice(0, 5),
      personal_records: personalRecords.slice(0, 5)
    } as ProfileDashboard
  } catch (error) {
    console.error('Error fetching profile dashboard:', error)
    return null
  }
}